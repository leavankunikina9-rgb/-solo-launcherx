package com.sovereign.solo

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private var timerView: TextView? = null
    private val tick = object : Runnable { override fun run() { updateTimer(); ui.postDelayed(this, 1000) } }

    override fun onCreate(b: Bundle?) { super.onCreate(b); build() }
    override fun onResume() { super.onResume(); build(); ui.post(tick) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }
    @Deprecated("Deprecated in Java") override fun onBackPressed() { /* a launcher has no back */ }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tv(t: String, size: Float, color: Int = Color.parseColor("#9BE7FF"), bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); typeface = if (bold) Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) else Typeface.MONOSPACE; setPadding(0, dp(3), 0, dp(3))
    }
    private fun btn(t: String, on: Boolean = true, f: () -> Unit) = Button(this).apply { text = t; isEnabled = on; setOnClickListener { f() } }
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun updateTimer() {
        val tvw = timerView ?: return
        val g = Store.gateEnd(this) - Store.now(); val pz = Store.passEnd(this) - Store.now()
        tvw.text = when {
            g > 0 -> "DUNGEON MODE · FOCUS ${fmt(g)}"
            Store.gateEnd(this) > 0 -> "GATE CLEARED · CLAIM YOUR REWARD"
            pz > 0 -> "FREE MODE · PASS ${fmt(pz)}"
            else -> "FREE MODE · ENTERTAINMENT LOCKED"
        }
    }
    private fun fmt(ms: Long): String { val s = ms / 1000; return "%02d:%02d".format(s / 60, s % 60) }

    private fun build() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(40), dp(18), dp(24)) }
        val xp = Store.xp(this); val lv = Store.level(xp); val (cur, need) = Store.levelXp(xp)
        root.addView(tv("SYSTEM INTERFACE · ONLINE", 12f, Color.parseColor("#38BDF8"), true))
        root.addView(tv("PLAYER STATUS", 18f, Color.WHITE, true))
        root.addView(tv("LEVEL %02d · RANK %s".format(lv, Store.rank(lv)), 22f, Color.parseColor("#A78BFA"), true))
        root.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = need; progress = cur })
        root.addView(tv("XP $cur/$need   GOLD ${Store.gold(this)}   FATIGUE ${Store.fatigue(this)}%", 13f))
        timerView = tv("", 14f, Color.parseColor("#FACC15"), true).also { root.addView(it) }
        updateTimer()

        root.addView(tv("\nDAILY QUEST", 15f, Color.WHITE, true))
        Store.QUESTS.forEachIndexed { i, q ->
            root.addView(CheckBox(this).apply {
                text = q; setTextColor(Color.parseColor("#9BE7FF")); isChecked = Store.questDone(this@MainActivity, i); isEnabled = !isChecked
                setOnCheckedChangeListener { _, on -> if (on) { Store.doQuest(this@MainActivity, i); toast("Quest cleared: +20 XP +60 gold"); build() } }
            })
        }

        root.addView(tv("\nFOCUS PROTOCOL", 15f, Color.WHITE, true))
        val gOn = Store.gateOn(this); val done = !gOn && Store.gateEnd(this) > 0
        root.addView(btn("ENTER GATE (${Store.GATE_MIN} MIN)", !gOn && !done) { Store.enterGate(this); build() })
        root.addView(btn("CLAIM GATE REWARD", done) { if (Store.completeGate(this)) toast("+${Store.GATE_XP} XP +${Store.GATE_GOLD} gold"); build() })
        root.addView(btn("ABANDON GATE (FATIGUE +30)", gOn) { Store.abandonGate(this); toast("Gate abandoned. Fatigue rises."); build() })
        root.addView(btn("BUY ENTERTAINMENT: ${Store.PASS_MIN} MIN FOR ${Store.PASS_COST} GOLD") { toast(Store.buyPass(this)); build() })

        root.addView(tv("\nINVENTORY", 15f, Color.WHITE, true))
        val search = EditText(this).apply { hint = "type to find an app"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); typeface = Typeface.MONOSPACE }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val apps = packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { Pair(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }.sortedBy { it.first.lowercase() }
        fun fill(q: String) {
            list.removeAllViews()
            apps.filter { it.first.contains(q, true) && it.second != packageName }.forEach { (name, pkg) ->
                val ent = pkg in Store.ENT
                list.addView(tv((if (ent) "[S-RANK HAZARD] " else "") + name, 15f, if (ent) Color.parseColor("#F472B6") else Color.parseColor("#9BE7FF")).apply {
                    setPadding(0, dp(9), 0, dp(9)); setOnClickListener { open(name, pkg) }
                })
            }
        }
        fill(""); search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { fill(s.toString()) }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        root.addView(search); root.addView(list)
        root.addView(btn("SOLO GUARD SETUP (ACCESSIBILITY)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        root.addView(tv("Turn on Solo Guard so blocked apps are stopped even when opened from outside this launcher.", 11f, Color.GRAY))
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#05080C")); addView(root) })
    }

    private fun open(name: String, pkg: String) {
        if (Store.blocked(this, pkg)) { startActivity(Intent(this, BlockActivity::class.java).putExtra("pkg", name)); return }
        packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
    }
}
