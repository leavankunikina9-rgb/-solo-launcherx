package com.sovereign.solo

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class BlockActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var left: TextView
    private val tick = object : Runnable { override fun run() { upd(); ui.postDelayed(this, 1000) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val name = intent.getStringExtra("pkg") ?: "this app"
        fun t(s: String, sz: Float, c: Int) = TextView(this).apply { text = s; textSize = sz; setTextColor(c); gravity = Gravity.CENTER; typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD); setPadding(0, 12, 0, 12) }
        left = t("", 18f, Color.parseColor("#FACC15"))
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(40, 40, 40, 40); setBackgroundColor(Color.parseColor("#12040A"))
            addView(t("ACCESS DENIED", 28f, Color.parseColor("#F43F5E")))
            addView(t(if (Store.gateOn(this@BlockActivity)) "DUNGEON MODE ACTIVE" else "ENTERTAINMENT LOCKED", 18f, Color.WHITE))
            addView(t("Your current mission has priority.", 14f, Color.parseColor("#9BE7FF")))
            addView(t("RESTRICTED APPLICATION: ${name.uppercase()}", 14f, Color.parseColor("#F472B6")))
            addView(left)
            addView(t("RETURN TO YOUR MISSION.", 14f, Color.WHITE))
            addView(Button(this@BlockActivity).apply { text = "RETURN"; setOnClickListener { finish() } })
        }
        setContentView(root)
    }
    private fun upd() {
        val g = Store.gateEnd(this) - Store.now()
        left.text = if (g > 0) "REMAINING FOCUS TIME: %02d:%02d".format(g / 60000, g / 1000 % 60) else "BUY A PASS WITH GOLD FROM A CLEARED GATE"
    }
    override fun onResume() { super.onResume(); ui.post(tick) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(tick) }
}
