package com.sovereign.solo

import android.content.Context

/** All rules live here. First principle: the rules are code, not willpower. */
object Store {
    // Entertainment "artifacts" the System controls. Add or remove package names freely.
    val ENT = setOf(
        "com.google.android.youtube", "com.zhiliaoapp.musically", "com.instagram.android",
        "com.netflix.mediaclient", "com.facebook.katana", "com.twitter.android",
        "com.snapchat.android", "com.crunchyroll.crunchyroid", "com.reddit.frontpage"
    )
    const val GATE_MIN = 90          // one deep-focus gate
    const val PASS_MIN = 25          // one purchased entertainment window
    const val PASS_COST = 500        // gold; about two hours of focused study
    const val GATE_GOLD = 375
    const val GATE_XP = 45
    const val MIN_LEVEL_FOR_PASS = 3 // rank gate: E-rank hunters cannot buy entertainment

    private fun p(c: Context) = c.getSharedPreferences("solo", Context.MODE_PRIVATE)
    fun now() = System.currentTimeMillis()
    fun xp(c: Context) = p(c).getInt("xp", 0)
    fun gold(c: Context) = p(c).getInt("gold", 0)
    fun fatigue(c: Context) = p(c).getInt("fatigue", 0)
    fun gateEnd(c: Context) = p(c).getLong("gateEnd", 0)
    fun passEnd(c: Context) = p(c).getLong("passEnd", 0)
    fun lockEnd(c: Context) = p(c).getLong("lockEnd", 0)
    fun gateOn(c: Context) = now() < gateEnd(c)
    fun passOn(c: Context) = now() < passEnd(c)

    fun level(xp: Int): Int { var x = xp; var l = 1; while (x >= 100 + 25 * (l - 1)) { x -= 100 + 25 * (l - 1); l++ }; return l }
    fun levelXp(xp: Int): Pair<Int, Int> { var x = xp; var l = 1; while (x >= 100 + 25 * (l - 1)) { x -= 100 + 25 * (l - 1); l++ }; return Pair(x, 100 + 25 * (l - 1)) }
    fun rank(l: Int) = when { l >= 30 -> "S"; l >= 20 -> "A"; l >= 15 -> "B"; l >= 10 -> "C"; l >= 5 -> "D"; else -> "E" }

    /** Rule 1 and 2: entertainment is blocked during a gate, while locked out, and whenever no pass is active. */
    fun blocked(c: Context, pkg: String) = pkg in ENT && (gateOn(c) || now() < lockEnd(c) || !passOn(c))

    fun enterGate(c: Context) { p(c).edit().putLong("gateEnd", now() + GATE_MIN * 60000L).apply() }
    fun completeGate(c: Context): Boolean {
        if (gateOn(c) || gateEnd(c) == 0L) return false
        p(c).edit().putInt("xp", xp(c) + GATE_XP).putInt("gold", gold(c) + GATE_GOLD).putLong("gateEnd", 0).apply(); return true
    }
    fun abandonGate(c: Context) { // leaving a gate early raises Fatigue; at 100 entertainment locks for 24 hours
        val f = fatigue(c) + 30
        val e = p(c).edit().putLong("gateEnd", 0)
        if (f >= 100) e.putInt("fatigue", 0).putLong("lockEnd", now() + 24 * 3600000L) else e.putInt("fatigue", f)
        e.apply()
    }
    fun buyPass(c: Context): String {
        if (gateOn(c)) return "Finish your gate first."
        if (level(xp(c)) < MIN_LEVEL_FOR_PASS) return "Rank too low. Reach level $MIN_LEVEL_FOR_PASS."
        if (gold(c) < PASS_COST) return "Not enough gold. Clear a gate."
        p(c).edit().putInt("gold", gold(c) - PASS_COST).putLong("passEnd", now() + PASS_MIN * 60000L).apply(); return "Pass active for $PASS_MIN minutes."
    }

    // Daily quests: three missions, each pays once per day.
    val QUESTS = listOf("Complete assigned homework", "Revise today's lessons", "Solve past-paper questions")
    private fun day() = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date())
    fun questDone(c: Context, i: Int) = p(c).getString("q$i", "") == day()
    fun doQuest(c: Context, i: Int) { if (!questDone(c, i)) p(c).edit().putString("q$i", day()).putInt("xp", xp(c) + 20).putInt("gold", gold(c) + 60).apply() }
}
