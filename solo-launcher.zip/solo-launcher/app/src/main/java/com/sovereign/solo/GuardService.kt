package com.sovereign.solo

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/** Rule 1 enforcement: when a blocked app comes to the front, send the user home and show ACCESS DENIED. */
class GuardService : AccessibilityService() {
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val pkg = e?.packageName?.toString() ?: return
        if (pkg == packageName || !Store.blocked(this, pkg)) return
        performGlobalAction(GLOBAL_ACTION_HOME)
        startActivity(Intent(this, BlockActivity::class.java).putExtra("pkg", pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
    override fun onInterrupt() {}
}
