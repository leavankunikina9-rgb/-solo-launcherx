# Solo Launcher (Android)

A Solo Leveling style home screen with a Focus Protocol and an app blocker.

## Build
1. Install Android Studio. Choose File > Open and pick this folder. Let Gradle sync.
2. Plug in your phone (USB debugging on) and press Run.

## Make it your default launcher
Android > Settings > Apps > Default apps > Home app > Solo Launcher.
(Or press Home after install and choose Solo Launcher > Always.)

## Turn on the blocker
Open the launcher > SOLO GUARD SETUP > Solo Guard > On. Without it, blocked apps are only
blocked when opened from this launcher, not from notifications or recents.

## Rules built in (see Store.kt)
- Entering a Gate (90 min) blocks entertainment apps until the timer ends.
- Entertainment is a consumable: 500 gold buys 25 minutes, from level 3 upward. Gold comes from cleared gates and quests.
- Abandoning a Gate adds Fatigue. At 100 Fatigue entertainment locks for 24 hours.
- Educational apps are never blocked. Change the ENT list to suit you.

## Limits (honest)
A normal app cannot stop you from disabling the accessibility service or uninstalling it.
Stronger lockdown needs device-owner or parental-control tooling. This project has not been compiled by its author's tools; expect to fix small build issues.
